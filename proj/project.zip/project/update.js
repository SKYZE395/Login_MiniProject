const mysql = require("mysql");
const express = require("express");
const bodyParser = require("body-parser");
const encoder = bodyParser.urlencoded();

const app = express();
app.use("/assets",express.static("assets"));
const connection = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"Aakashisgood@123",
    database:"nodejs"
});

connection.connect(function(error){
    if(error) throw error
    else console.log("connection success")
});

app.get("/",function(req,res){
    res.sendFile(__dirname +"/welcome.html");
})

app.get("/first",function(req,res){
    res.sendFile(__dirname +"/first.html")
})

app.post("/",encoder,function(req,res){
    var password = req.body.cnfpass;
    connection.query("update loginuser set user_passN = ? where user_name = ?",[password,"admin"],function(error,results,fields){
        if(results.affectedRows==1){
            res.redirect("/first");
        }
        else{
            console.log(error);
            res.redirect("/welcome");
        }
        res.end();
    });
})
app.listen(4000);