const mysql = require('mysql');
const express = require('express');
const bodyParser = require('body-parser');
const encoder = bodyParser.urlencoded({extended:true});
const app = express();
const ejs = require('ejs');

app.use("/assets",express.static("assets"));
const connection = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"Aakashisgood@123",
    database:"nodejs"
});

app.set('view engine','ejs');

connection.connect(function(error){
    if(error) 
        throw error;
    else 
        console.log("listening to port 4000");
});

app.get('/',(req,res)=>{
    res.render('index');
});

app.get('/changepass',(req,res)=>{
    const msg = '';
    res.render('changepass',{msg});
});

var username;

app.post('/',encoder,(req,res)=>{
    username = req.body.username;
    var password = req.body.password;
    connection.query("select * from loginuser where user_name = ? and user_passN = ?",[username,password],function(error,results,fields){
        if(results.length>0){
            res.redirect('/changepass');
        }
        else{
            res.redirect('/');
        }
        res.end();
    });
})

app.get('/home',function(req,res){
    res.render('home');
});

app.post('/changepass',encoder,(req,res)=>{
    var pass1 = req.body.cnfpass1;
    var pass2 = req.body.cnfpass2;
    if(pass1==pass2){
        connection.query("update loginuser set user_passN = ? where user_name = ?",[pass1,username],function(error,results,fields){
            if(results.affectedRows==1){
                res.redirect('/home');
                username="";
            }
            else{
                alert("error");
                console.log(error);
            }
            res.end();
        });
    }
    else{
        const msg = 'fields do not match';
        res.render('changepass',{msg});
    }
})

app.get('/time_table',function(req,res){
    res.render(__dirname+'/views/askfortt');
});

app.use('/',(req,res)=>{
    res.render(__dirname+"/views/404");
});

app.listen(4000);